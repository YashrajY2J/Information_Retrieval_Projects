import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.*;
import java.util.Scanner;
import org.json.JSONObject;

public class FakeNewsMain {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("=== Fake News Detection System ===");
        System.out.print("Enter article title: ");
        String title = sc.nextLine();
        System.out.println("Enter article content: ");
        String content = sc.nextLine();

        NewsArticle article = new NewsArticle(title, content);

        try {
            // Call Python Flask API
            String apiUrl = "http://127.0.0.1:5000/predict";
            JSONObject req = new JSONObject();
            req.put("text", content);
            String resp = postJson(apiUrl, req.toString());
            JSONObject json = new JSONObject(resp);
            if (json.has("prediction")) {
                String pred = json.getString("prediction");
                double conf = json.has("confidence") && !json.isNull("confidence") ? json.getDouble("confidence") : 0.0;
                article.setPredictedLabel(pred);
                article.setConfidence(conf);
                System.out.println("Prediction: " + pred + " (confidence: " + conf + ")");
                saveToDatabase(article);
            } else {
                System.out.println("Prediction failed: " + json.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        sc.close();
    }

    private static String postJson(String apiUrl, String jsonInput) throws IOException {
        URL url = new URL(apiUrl);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json; utf-8");
        con.setDoOutput(true);
        try(OutputStream os = con.getOutputStream()) {
            byte[] input = jsonInput.getBytes("utf-8");
            os.write(input, 0, input.length);
        }
        StringBuilder resp = new StringBuilder();
        try(BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(),"utf-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                resp.append(line.trim());
            }
        }
        return resp.toString();
    }

    private static void saveToDatabase(NewsArticle article) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO articles (title, content, predicted_label, confidence) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, article.getTitle());
                ps.setString(2, article.getContent());
                ps.setString(3, article.getPredictedLabel());
                ps.setDouble(4, article.getConfidence());
                ps.executeUpdate();
                System.out.println("✅ Saved to database successfully!");
            }
        } catch (SQLException e) {
            System.out.println("❌ DB save failed. Check MySQL credentials.");
            e.printStackTrace();
        }
    }
}
