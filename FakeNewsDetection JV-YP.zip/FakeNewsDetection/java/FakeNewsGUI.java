import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.sql.*;
import org.json.JSONObject;

public class FakeNewsGUI extends JFrame {

    private JTextField titleField;
    private JTextArea contentArea;
    private JButton detectButton, clearButton;
    private JLabel resultLabel;
    private Connection conn;

    public FakeNewsGUI() {
        // ===== Window setup =====
        setTitle("📰 Fake News Detection System");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(15, 15));
        getContentPane().setBackground(new Color(30, 33, 45));

        // ===== Header Panel =====
        JPanel header = new JPanel();
        header.setBackground(new Color(25, 118, 210));
        JLabel title = new JLabel("Fake News Detection System");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        header.add(title);
        add(header, BorderLayout.NORTH);

        // ===== Input Panel =====
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridBagLayout());
        inputPanel.setBackground(new Color(30, 33, 45));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("Article Title:");
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        gbc.gridx = 0; gbc.gridy = 0;
        inputPanel.add(lblTitle, gbc);

        titleField = new JTextField();
        titleField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        titleField.setBackground(new Color(45, 49, 66));
        titleField.setForeground(Color.WHITE);
        titleField.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        gbc.gridx = 1; gbc.gridy = 0; gbc.gridwidth = 2;
        inputPanel.add(titleField, gbc);

        JLabel lblContent = new JLabel("Article Content:");
        lblContent.setForeground(Color.WHITE);
        lblContent.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        inputPanel.add(lblContent, gbc);

        contentArea = new JTextArea(8, 40);
        contentArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        contentArea.setBackground(new Color(45, 49, 66));
        contentArea.setForeground(Color.WHITE);
        contentArea.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        JScrollPane scrollPane = new JScrollPane(contentArea);
        gbc.gridx = 1; gbc.gridy = 1; gbc.gridwidth = 2;
        inputPanel.add(scrollPane, gbc);

        add(inputPanel, BorderLayout.CENTER);

        // ===== Bottom Panel (Buttons + Result) =====
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.setBackground(new Color(30, 33, 45));

        // Buttons Row
        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonRow.setBackground(new Color(30, 33, 45));

        detectButton = new JButton("🔍 Detect Fake News");
        detectButton.setBackground(new Color(25, 118, 210));
        detectButton.setForeground(Color.WHITE);
        detectButton.setFocusPainted(false);
        detectButton.setFont(new Font("Segoe UI", Font.BOLD, 15));
        detectButton.setPreferredSize(new Dimension(200, 40));
        styleButton(detectButton);

        clearButton = new JButton("🧹 Clear");
        clearButton.setBackground(new Color(220, 53, 69));
        clearButton.setForeground(Color.WHITE);
        clearButton.setFont(new Font("Segoe UI", Font.BOLD, 15));
        clearButton.setPreferredSize(new Dimension(120, 40));
        styleButton(clearButton);

        buttonRow.add(detectButton);
        buttonRow.add(clearButton);

        // Result Label
        resultLabel = new JLabel("Prediction: --", SwingConstants.CENTER);
        resultLabel.setForeground(Color.WHITE);
        resultLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));

        bottomPanel.add(buttonRow, BorderLayout.NORTH);
        bottomPanel.add(resultLabel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        // ===== Connect DB =====
        try {
            conn = DBConnection.getConnection();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database connection failed!", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // ===== Action Listeners =====
        detectButton.addActionListener(e -> detectFakeNews());
        clearButton.addActionListener(e -> {
            titleField.setText("");
            contentArea.setText("");
            resultLabel.setText("Prediction: --");
        });
    }

    private void styleButton(JButton btn) {
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private void detectFakeNews() {
        String title = titleField.getText().trim();
        String content = contentArea.getText().trim();

        if (content.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter article content!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String apiUrl = "http://127.0.0.1:5000/predict";
            JSONObject req = new JSONObject();
            req.put("text", content);

            String resp = postJson(apiUrl, req.toString());
            JSONObject json = new JSONObject(resp);

            if (json.has("prediction")) {
                String pred = json.getString("prediction");
                double conf = json.optDouble("confidence", 0.0);

                resultLabel.setText("Prediction: " + pred.toUpperCase() + " | Confidence: " + String.format("%.2f", conf));
                saveToDatabase(title, content, pred, conf);

                JOptionPane.showMessageDialog(this,
                        "✅ Prediction: " + pred.toUpperCase() + "\nSaved to Database Successfully!",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Prediction failed!", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "API Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private String postJson(String apiUrl, String jsonInput) throws IOException {
        URL url = new URL(apiUrl);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json; utf-8");
        con.setDoOutput(true);
        try (OutputStream os = con.getOutputStream()) {
            byte[] input = jsonInput.getBytes("utf-8");
            os.write(input, 0, input.length);
        }
        StringBuilder resp = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                resp.append(line.trim());
            }
        }
        return resp.toString();
    }

    private void saveToDatabase(String title, String content, String pred, double conf) {
        try {
            String sql = "INSERT INTO articles (title, content, predicted_label, confidence) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, title);
            ps.setString(2, content);
            ps.setString(3, pred);
            ps.setDouble(4, conf);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "DB Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FakeNewsGUI app = new FakeNewsGUI();
            app.setVisible(true);
        });
    }
}
