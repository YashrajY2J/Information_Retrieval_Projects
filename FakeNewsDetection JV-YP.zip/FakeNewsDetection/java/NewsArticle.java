public class NewsArticle {
    private int id;
    private String title;
    private String content;
    private String predictedLabel;
    private double confidence;

    public NewsArticle(String title, String content) {
        this.title = title;
        this.content = content;
    }

    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getPredictedLabel() { return predictedLabel; }
    public void setPredictedLabel(String l) { this.predictedLabel = l; }
    public double getConfidence() { return confidence; }
    public void setConfidence(double c) { this.confidence = c; }
}
