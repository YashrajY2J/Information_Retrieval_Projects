from flask import Flask, request, jsonify
import joblib
import traceback

app = Flask(__name__)

MODEL_PATH = "../model/vectorizer_and_model.joblib"

try:
    model = joblib.load(MODEL_PATH)
    print("✅ Model loaded successfully!")
except Exception as e:
    print("❌ Failed to load model:", e)
    model = None

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        text = data.get('text', '')
        if model is None:
            return jsonify({'error': 'model not loaded'}), 500

        pred = model.predict([text])[0]
        prob = None
        if hasattr(model, 'predict_proba'):
            prob = float(max(model.predict_proba([text])[0]))

        return jsonify({'prediction': pred, 'confidence': prob})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("✅ Flask ML API running at http://127.0.0.1:5000/predict")
    app.run(host='127.0.0.1', port=5000)
